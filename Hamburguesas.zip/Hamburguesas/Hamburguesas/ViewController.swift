//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Romina Pozzuto on 03/11/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelPaises: UILabel!
    @IBOutlet weak var labelHamburguesa: UILabel!
    @IBOutlet weak var labelPrecio: UILabel!
    
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesa()
    let precio = ColeccionDePrecios()
    let colores = Colores()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func dameUnaHamburguesa(_ sender: Any) {
        labelPaises.text = paises.obtenPais()
        labelHamburguesa.text = hamburguesas.obtenHamburguesa()
        labelPrecio.text = precio.obtenPrecio()
        let colorAleatorio = colores.regresaColoreAleatorio()
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
        
    }
    
    
    


}

